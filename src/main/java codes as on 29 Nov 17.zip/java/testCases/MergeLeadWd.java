package testCases;

import org.junit.Test;
import org.openqa.selenium.WebElement;

import wdMethods.SeMethods;

public class MergeLeadWd extends SeMethods
{
	@Test
	public  void MergeLead() throws InterruptedException
	{
		//Launch the browser
		startApp("chrome", "http://leaftaps.com/opentaps");
		WebElement eleUserName = locateElement("id", "username");
		
		//Enter the username
		type(eleUserName, "DemoSalesManager");	
		
		//Enter the password
		type(locateElement("id", "password"), "crmsfa");
		
		//Click Login
		click(locateElement("class", "decorativeSubmit"));
		
		//Click crm/sfa link
		click(locateElement("xpath","//a[contains(text(),'CRM/SFA')]"));
		
		//Click Leads link
		click(locateElement("linkText", "Leads"));
		
		//Click Merge leads
		click(locateElement("xpath","//a[contains(text(),'Merge Leads')]"));
		
		//Click on Icon near From Lead
		click(locateElement("xpath","//img[@alt='Lookup']"));
		
		//Move to new window
		switchToWindow(1);
		
		//Enter Lead ID
		type(locateElement("Name","id"),"8");
		
		
		//Click Find Leads 
		click(locateElement("xpath", "//div[@class='x-grid3-hd-inner x-grid3-hd-partyId']"));
		Thread.sleep(3000);
		
		//Click First Resulting lead
		click(locateElement("xpath", "//a[@class='linktext']"));
		
		//Switch back to primary window
		switchToWindow(0);
		
		//Click on Icon near To Lead
		click(locateElement("xpath","//img[@src='/images/fieldlookup.gif']"));
		
		//Move to new window
		switchToWindow(1);
		
		//Enter Lead ID
		type(locateElement("Name","id"),"10022");
		
		//Click Find Leads button
		click(locateElement("class", "x-btn-text"));
		
		//Click First Resulting lead
		click(locateElement("class", "x-btn-text"));
		
	
		//Switch back to primary window
		switchToWindow(0);
		
		//Click Merge
		click(locateElement("LinkText", "Merge"));
		
		//Accept Alert
		//Click Find Leads
		//Enter From Lead ID
		//Click Find Leads
		//Verify error msg
		//Close the browser (Do not log out)	
				
	}

	@Override
	public String getText(WebElement ele) {
		// TODO Auto-generated method stub
		return null;
	}

}
