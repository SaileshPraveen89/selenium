package testCases;

import org.junit.Test;
import org.openqa.selenium.WebElement;

import wdMethods.SeMethods;

public class DuplicateLeadWd extends SeMethods
{
	@Test	
	public void duplicateLead() throws InterruptedException
	{
		//Launch the browser
		startApp("chrome", "http://leaftaps.com/opentaps");
		
		//Enter the username
		WebElement eleUserName = locateElement("id", "username");
		type(eleUserName, "DemoSalesManager");	
		
		//Enter the password
		type(locateElement("id", "password"), "crmsfa");
		
		//Click Login
		click(locateElement("class", "decorativeSubmit"));
		
		//Click crm/sfa link
		click(locateElement("LinkText", "CRM/SFA"));
		
		//Click Leads link
		click(locateElement("LinkText", "Leads"));
		
		//Click Find leads
		click(locateElement("LinkText", "Find Leads"));
		
		//Click on Email
		click(locateElement("LinkText", "Email"));
		
		//Enter Email
		type(locateElement("Name", "emailAddress"),"vinodck@gmail.com");
		
		//Click find leads button
		click(locateElement("xpath","//button[contains(text(),'Find Leads')]"));
		
		//Capture name of First Resulting lead

		
		//Click First Resulting lead
		click(locateElement("xpath","//div[@class='x-grid3-cell-inner x-grid3-col-firstName']"));		
		click(locateElement("xpath","//div[@class='x-grid3-cell-inner x-grid3-col-partyId']"));
		click(locateElement("xpath","//a[contains(text(),'10310')]"));
		
		//Click Duplicate Lead
		click(locateElement("xpath","//a[contains(text(),'Duplicate Lead')]"));
		
		//Verify the title as 'Duplicate Lead'
		getText("Duplicate Lead | opentaps CRM");
		click(locateElement("Name", "submitButton"));
		
		//Confirm Duplicate Name is Captured Name		
		String duplicateLead = getText(locateElement("id","viewLead_firstName_sp"));
		System.out.println("The Duplicate value :" +duplicateLead);
		
		String captureName = null;
		if(captureName.equalsIgnoreCase(duplicateLead))
		{
			System.out.println("The captured Name and duplicate lead name are same");
		} else
		{
			System.out.println("The captured name and duplicate lead name are different");
		}
		
		
		
	}
}
