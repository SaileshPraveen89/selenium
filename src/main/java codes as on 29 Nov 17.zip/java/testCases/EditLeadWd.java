package testCases;

import org.junit.Test;

import wdMethods.SeMethods;

public class EditLeadWd extends ProjectManager
{

	@Test
	public void EditLead() throws InterruptedException
	{
	login();
	
	//Click crm/sfa link
	click(locateElement("LinkText", "CRM/SFA"));
	
	//Click Leads link
	click(locateElement("LinkText", "Leads"));
	
	//Click Find leads
	click(locateElement("LinkText", "Find Leads"));
	

	//Enter the first Name
	type(locateElement("xpath", "(//input[@name= 'firstName'])[3]"),"Praveen");
	
	//Click Find leads button
	//Click on first resulting lead
	//Verify title of the page
	//Click Edit
	//Change the company name
	//Click Update
	//Confirm the changed name appears
	//Close the browser (Do not log out)
	
	//Click Find leads button
	click(locateElement("xpath", "//button[text() = 'Find Leads']"));
	Thread.sleep(3000);
	
	//Click on first resulting lead
	click(locateElement("xpath", "(//tbody//a[(@class='linktext')])[1]"));
	
	//Verify title of the page
	verifyTitle("View Lead | opentaps CRM");
	
	//Click Edit
	click(locateElement("link", "Edit"));
	
	//Change the company name
	type(locateElement("id", "updateLeadForm_companyName"), "Infosys");
	
	//Click Update
	click(locateElement("class", "smallSubmit"));	
	
	//	Confirm the changed name appears and	Close the browser (Do not log out)
	verifyPartialText(locateElement("id", "viewLead_companyName_sp"), "Infosys");
	//logout();
	
		
	}

}
